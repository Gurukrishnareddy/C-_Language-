#include <stdio.h>
#include <stdlib.h>

int Num;

struct date
   {
   int year;
   int month;
   int day;
    };

int yrr(int year, int month)
{
    if (month <= 2)
   year = year - 1;
    else
   year = year;
    return year;
}

int g(int month)
{
    if (month <= 2)
   month = month + 13;
    else
   month = month + 1;
    return month;
}


int n(int year, int month, int day)
{
    Num = 1461 * yrr(year, month) / 4 + 153 * g(month) / 5 + day;
    return Num;
}


int main(void)
{
    int result;

    struct date date1, date2;

    int n(int year, int month, int day);
    int yrr(int year, int month);
    int g(int month);

    printf("Enter start date (YYYY:MM:DD): ");
    scanf("%i:%i:%i",&date1.year, &date1.month, &date1.day );

    printf("Enter end date (YYYY:MM:DD): ");
    scanf("%i:%i:%i",&date2.year, &date2.month, &date2.day);

    result = n(date2.year, date2.month, date2.day) - n(date1.year,date1.month, date1.day);

    printf("Total days between start & end dates is: %i\n", result);

    return 0;
}

	
	
	

