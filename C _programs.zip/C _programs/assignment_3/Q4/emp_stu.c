#include<stdio.h>
#include <stdlib.h>
#include <string.h>


struct emp
{
        char emp_name[10];
        char emp_designation[10];
        int emp_no;
        int emp_salary;
        //int arr[20];
};

int main()
{
        // memory allocating to structure variables Empoyee_1.

        struct emp *employee_1; //,*employee_2,*employee_3;

        employee_1 = (struct emp*)malloc(sizeof(struct emp));
        printf("Enter the Employee_1 details\n");
scanf("%s,%s,%d,%d\n",employee_1->emp_name, employee_1->emp_designation, &employee_1->emp_no, &employee_1->emp_salary);



printf("%s,%s,%d,%d\n",employee_1->emp_name, employee_1->emp_designation, employee_1->emp_no, employee_1->emp_salary);
return 0;
}
