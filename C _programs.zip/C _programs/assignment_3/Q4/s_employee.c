#include<stdio.h>
#include <stdlib.h>
#include <string.h>


struct emp
{
	char emp_name[10];
	char emp_designation[10];
	int emp_no;
	int emp_salary;
	//int arr[20];
};

int main()
{
	// memory allocating to structure variables Empoyee_1.

	struct emp *employee_1,*employee_2,*employee_3;

	employee_1 = (struct emp*)malloc(sizeof(struct emp));
	printf("Enter the Employee_1 details\n");
scanf("%s,%s,%d,%d\n",employee_1->emp_name, employee_1->emp_designation, &employee_1->emp_no, &employee_1->emp_salary);


	printf("Dislpying The Employee_1\n");
        printf("%s,%s,%d,%d\n",employee_1->emp_name,employee_1->emp_designation,employee_1->emp_no,employee_1->emp_salary);

free(employee_1);


	// memory allocating to structure variables Employee_2.

	employee_2 = (struct emp*)malloc(sizeof(struct emp));
	printf("\n Enter the Employee_2 details \n");
scanf("%s,%s,%d,%d\n",employee_2->emp_name, employee_2->emp_designation, &employee_2->emp_no, &employee_2->emp_salary);
	printf("Dislpying The  Employee_2\n");
        printf("%s,%s,%d,%d\n",employee_2->emp_name,employee_2->emp_designation,employee_2->emp_no,employee_2->emp_salary);
	free(employee_2);



	// displaying to structure variable Employee_1 and Employee_2 details..
   	//printf("Dislpying The Employee_1\n");
	//printf("%s %s %d %d\n",employee_1->emp_name,employee_1->emp_designation,employee_1->emp_no,employee_1->emp_salary);   
	//printf("Dislpying The  Employee_2\n"); 
	//printf("%s %s %d %d\n",employee_2->emp_name,employee_2->emp_designation,employee_2->emp_no,employee_2->emp_salary);

	employee_3=(struct emp*)malloc(sizeof(struct emp));

	// coping the empoyee_1 to employee_3

	printf("coping employee_1 details to employee_3\n");
	strcpy(employee_3->emp_name,employee_1->emp_name);
	strcpy(employee_3->emp_designation,employee_1->emp_designation);
	employee_3->emp_no=employee_1->emp_no;
	employee_3->emp_salary=employee_1->emp_salary;

	printf("Employee_3 details\n");
	printf("%s,%s,%d,%d\n",employee_3->emp_name,employee_3->emp_designation,employee_3->emp_no,employee_3->emp_salary);
	
	// comparing employee_1 with employee_3
	
	printf("comparing Employee_1 with Empoyee_3\n");

	int x=(strcmp(employee_1->emp_name,employee_3->emp_name));
	if(x==0)
	{
	printf("Employee names are equal\n");
	}
	else 
	{
	printf("Employee names are not same\n ");
	}

	int y=(strcmp(employee_1->emp_designation,employee_3->emp_designation));
	if(y==0)
        {
        printf("Employee names are equal\n");
        }
        else
        {
        printf("Employee names are not same\n ");
        }
	free(employee_3);
	return 0;
}







