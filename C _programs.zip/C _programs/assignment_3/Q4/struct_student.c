#include <stdio.h>
#include <stdlib.h>
struct person {
   int id;
   char name[30];
   char branch[30];
};

int main()
{
   struct person *ptr;
   int i, n;

   printf("Enter the number of persons: ");
  scanf("%d", &n);

  // allocating memory for n numbers of struct person
   ptr = (struct person*) malloc(n * sizeof(struct person));

   for(i = 0; i < n; ++i)
   {
       printf("Enter first name and age respectively: ");
       // To access members of 1st struct person,
       // ptr->name and ptr->age is used

       // To access members of 2nd struct person,
       // (ptr+1)->name and (ptr+1)->age is used
       scanf("%s %d %s", (ptr+i)->name, &(ptr+i)->id, (ptr+i)->branch);
   }

   printf("Displaying Information:\n");
   for(i = 0; i < n; ++i)
       printf("Name: %s\tAge: %d\n branch: %s\t", (ptr+i)->name, (ptr+i)->id, (ptr+i)->branch);

   return 0;
}

	

