#include<stdio.h>
#include<stdlib.h>
struct time_seconds
{
    int hours;
    int mints;
    int secns;
};

typedef struct time_seconds Struct;

int total_seconds(struct time_seconds s)//conversion of hh:mm:ss to seconds
{
    int sum =0;
    if(s.hours < 24)  
    sum = s.hours * 60 * 60;
    if(s.mints < 60)  
    sum = sum + s.mints *60;
    if(s.secns < 60)  
    sum = sum + s.secns;
    return sum;  
}

Struct total_Hours(int sec)// structure returning type conversion of secs to hh:mm:ss
{
    struct time_seconds s;
   
    s.hours = (sec/3600);
    s.mints = (sec -(3600*s.hours))/60;
    s.secns = (sec -(3600*s.hours)-(s.mints*60));
    return s ; // returning structure s
}

int main()
{
     struct time_seconds s1;
     //struct time_seconds s2;
     char string[100]={0};// we intializing structure using string
     int total_secns=0;
     printf("\nEnter the time in \"HH:MM:SS\" format : ");
     fgets(string,100,stdin);//string input read fetch the hour,min and sec values from the string and then store it in int variables
                                                                                    // in order to validate them
     sscanf(string,"%d:%d:%d", &s1.hours,&s1.mints,&s1.secns);// Read about sscanf
     
     total_secns = total_seconds(s1);// calling function
     
     printf("Total Time is converted into seconds:%d\n",total_secns);
     
     //s2 = total_Hours(total_secns);//returning structure and assing to the s2 structure
     //printf("the time in \"hh:mm:ss\" format : %d:%d:%d\n",s2.hours,s2.mints,s2.secns);
     
     
     return 0;
}
