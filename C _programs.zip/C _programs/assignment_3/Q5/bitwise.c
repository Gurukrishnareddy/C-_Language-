#include<stdio.h>
struct packed_struct
                {
                unsigned int head:2;//2 bits
              unsigned int cmnd:8;//8 bits
                unsigned int length:8;//8 bits
                unsigned int payload:14;// 14 bits  
                };// 32 bits ------4 bytes memory allocated
int main()

                {
                struct packed_struct var;
                var.head=1;
                var.cmnd=2;
                var.length=3;
                var.payload=4;
		printf("number of bytes %ld",sizeof(struct packed_struct ));
return 0;
		}

