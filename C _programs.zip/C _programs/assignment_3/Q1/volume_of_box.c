#include<stdio.h>
struct rect {
    int length;
    int width;
    int height;
} ;
int fun1(struct rect box1);
int main()
{
    struct rect box1;
    int volume=0;
   
    printf("enter the length:-");
    scanf("%d",&box1.length);
    printf("enter the width:-");
    scanf("%d",&box1.width);
    printf("enter the height:-");
    scanf("%d",&box1.height);
    volume=fun1(box1);
    printf("Volume of a Box:- %d\n",volume);
    return 0;
}

int fun1(struct rect box1)
{
   int volume1=0;
   volume1 = ((box1.length)*(box1.width)*(box1.height));
   return volume1;
}
