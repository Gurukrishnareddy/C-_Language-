#include<stdio.h>

#include<string.h>

void *mem_cpy(void*,void*,int);

int main()

{

   char s1[100],s2[100],*p;

   int n;

   printf("enter the string1:");

   scanf("%[^\n]",s1);

   printf("enter the string2:");

   scanf("%[^\n]",s2);

   printf("enter the value of n:");

   scanf("%d\n",&n);

   p=mem_cpy(s1,s2,n);

   puts(s1);

   puts(s2);

}

void *mem_cpy(void *s1,void *s2,int n)

{

   int i;

   char *p=s1;

   char *q=s2;

    for(i=0;i<n;i++)

     {

        p[i]=q[i];

    }

  return p;

}
