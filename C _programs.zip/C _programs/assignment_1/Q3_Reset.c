#include <stdio.h>

int main()
{
 int n,pos,newnum;
 printf("enter the interger number:-");
 scanf("%d",&n);
printf("enter the bit position:-");
 scanf("%d",&pos);
 newnum=n&~(1<<pos);
 printf("%d\n",newnum);
 return 0;
}
 
