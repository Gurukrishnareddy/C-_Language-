#include <stdio.h>
 int add(int a, int b);
 int sub(int a,int b);
 int mul(int a,int b);
 int divs(int a,int b);
 
int (*arthmentic[4])(int,int);
int add(int a,int b)
{
    return(a+b);
}

int sub(int a,int b)
{
    return(a-b);
}
int mul(int a,int b)
{
    return(a*b);
    
}
int divs(int a,int b)
{
    return(a/b);
    
}

int main()
{
int a,b,result;
printf("enter the a value:- ");
scanf(" %d\n",&a);
printf("enter the b value:- ");
scanf(" %d\n",&b);
int (*arthmentic[4])(int,int);
arthmentic[0]=add;
arthmentic[1]=sub;
arthmentic[2]=mul;
arthmentic[3]=divs;

result=arthmentic[0](a,b);
printf("Addation of a & b =%d\n",result);
result=arthmentic[1](a,b);
printf("substraction of a & b =%d\n",result);
result=arthmentic[2](a,b);
printf("multiplication of a & b =%d\n",result);
result=arthmentic[3](a,b);
printf("Division  of a & b =%d\n",result);
return 0;
}

