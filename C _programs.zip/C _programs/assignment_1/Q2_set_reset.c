#include <stdio.h>

int main()
{
 int n,pos,newnum;
 printf("enter the interger number:-\n");
 scanf("%d\n",&n);
 printf("enter the bit position:-\n");
 scanf("%d\n",&pos);
 newnum=n|(1<<pos);
 printf("after set bit the value of %d\n",newnum);
 return 0;
}
