#include<stdio.h>

#include<stdarg.h>

int vsum(int num,...)

{

   va_list arguments;

    int sum=0;

   va_start(arguments,num);

   for(int x=0;x<num;x++)

   {

      sum+=va_arg(arguments,int);

   }

va_end(arguments);

return sum;

}

int main()

{

   printf("%d\n",vsum(1,10,22,4.5));

   printf("%d\n",vsum(5,3,2,1,5,3));

}
