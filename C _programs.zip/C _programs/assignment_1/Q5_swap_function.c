#include<stdio.h>
int swap(int *, int *);

int main(){

	int a,b,temp=0;

	printf("Enter a first integer: ");
	scanf("%d",&a);

	printf("Enter a second integer: ");
	scanf("%d",&b);
	temp=swap(&a,&b);
	printf("The numbers after swap are %d,%d \n",a,b);

return 0;
}

int swap(int *a,int *b){
	int temp;

	temp = *a;
	*a = *b;
	*b = temp;
return temp;
}

