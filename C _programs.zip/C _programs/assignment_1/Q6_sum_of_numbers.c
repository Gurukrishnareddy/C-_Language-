#include<stdio.h>

int sum_of_Numbers(int frist,int last);

int main()

{

   int frist,last,sum;

   printf("enter least limit: ");

   scanf("%d",&frist);

   printf("enter upper limit:");

   scanf("%d",&last);

   sum=sum_of_Numbers(frist,last);

   printf("sum of n numbers from %d to %d = %d\n",frist,last,sum);

   return 0;

}

int sum_of_Numbers(int frist,int last)

{

     if(frist == last)

          return frist;

     else

          return frist + sum_of_Numbers(frist + 1,last);

}
