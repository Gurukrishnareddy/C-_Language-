#include "mystring.h"
// string lengths..........
int length_of_string(char*p)
{
int count = 0;
while (*p != '\0')
{
count++;
p++;
}
return count;
}

// string compare...

int compare_string(char *first, char *second)
{
   while(*first==*second)
   {
      if ( *first == '\0' || *second == '\0' )
         break;

      first++;
      second++;
   }
   if( *first == '\0' && *second == '\0' )
      return 0;
   else
      return -1;
}
// string copy..
char my_str_cpy(char *dst,char *src)
       {
                while(*src!='\0')
                *dst++=*src++;
                *dst='\0';
                return 0;
       }
///string cat...
#include"mystring.h"
int my_str_cat(char *str4, char *str3)
{
    while(*str3)
    {
        str3++;
    }
    while(*str3)
    {
        *str3 = *str4;
        str3++;
        str4++;
    }
    *str3 = '\0';

}

