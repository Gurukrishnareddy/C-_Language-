#include<stdio.h>

#include<string.h>

///my_str_length..

int length_of_string(char*p);

///my_str_cpy

char my_str_cpy(char*, char*);

//my_str_cat

int my_str_cat(char*, char*);

///my string compare
int compare_string(char*, char*);
