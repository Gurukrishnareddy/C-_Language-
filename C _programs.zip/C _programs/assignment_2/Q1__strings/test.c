#include "mystring.h"
#include<string.h>
#include<stdio.h>

int main()
/// my string length

	{
		char str[100]="technology";
		int length;
		length = length_of_string(str);
		printf("\nThe length of the given string : %d\n", length);
// string copy	
             char str1[30]="Indian_Army";
             char str2[999];
             my_str_cpy(str2,str1);
             printf(" string 1 is copied in to string 2 sucessfully:-%s\n",str1);
// string cat
	     char str3[999]="Indian_";
    		char str4[999]="Army";
    		my_str_cat(str4,str3);
   		printf("string is \%s", str3);
		printf(" \n");
// string compare
    	char first[100]="technology", second[100]="technology", result;
    result = compare_string(first, second);
 
    if ( result == 0 )
       printf("Both strings are same.\n");
    else
       printf("Entered strings are not equal.\n");
  return 0;
}
