#include<stdio.h>

int main()

{

int count=0,a=0,length=0;

char name[]="abcdef";

char *ptr,*ptr1;

ptr=name;

ptr1=name;

char *name1=name;

while(*ptr!='\0')

{

length++;

ptr++;

}

printf("enter the position by which you have to rotate ");

scanf("%d",&count);

while(a<length )

{

*ptr++=*ptr1++;

name[a]='\0';

name1++;

a++;

}

name1++;

*ptr='\0';

printf("%s",name1);

 

return 0;

}
