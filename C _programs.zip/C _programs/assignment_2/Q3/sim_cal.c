#include<stdio.h>
#include<math.h>
int main()
{
  float n1,n2;              
  char operator;            
  printf("Enter an operator(+,-,/,*,^):");
  scanf("%c",&operator);    

  printf("Enter frist numbers:");
  scanf("%f",&n1);   
  printf("Enter second numbers:");
  scanf("%f",&n2);
  switch(operator)         
  {
      
    case'+' : printf("%.3f + %.3f = %.3f",n1,n2,(n1+n2)); 
              break;
    case'-' : printf("%.3f - %.3f = %.3f",n1,n2,(n1-n2));
              break;
    case'/' : printf("%.3f / %.3f = %.3f",n1,n2,(n1/n2));
              break;
    case'*' : printf("%.3f * %.3f = %.3f",n1,n2,(n1*n2));
              break;
    case'^' : printf("%.3f ^ %.3f = %.3f",n1,n2, pow(n1, n2));
              break;
    default: printf("Error! operator is wrong");

  }
  return 0;
}
