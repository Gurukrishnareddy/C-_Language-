#include<stdio.h>

#include<stdlib.h>

void main(int argc,char *argv[])

{

   int i,sum=0;

   if(argc!=3)

    {

       printf("you have target to type numbers");

        exit(1);

    }

printf("the sum is");

for(i=1;i<argc;i++)

  sum=sum+atoi(argv[i]);

  printf("%d",sum);

}
