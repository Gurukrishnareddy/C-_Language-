#include<stdio.h>

int max(int num,int num1);

int min(int num,int num1);

int main()

{

    int num,num1,maximum,minimum;

    printf("enter any two numbers:");

    scanf("%d %d",&num,&num1);

    maximum=max(num,num1);

    minimum=min(num,num1);

    printf("maximum=%d\n",maximum);

    printf("minimum=%d\n",minimum);

    return 0;

}

int max(int num,int num1)

{

   return(num>num1)?num:num1;

}

int min(int num,int num1)

{

    return(num>num1)?num1:num;

}
