#include<stdio.h>
#include<string.h>
#include<stdlib.h>


int main() {
   // Converting  str to int
   //
    char str3[10] = "99Hello!";
   int x = atoi(str3);
    printf("Converting '99Hello!': %d\n", x);
    return 0;
}
