#include<stdio.h>
int present(char str[],char n)
{
     char *ptr=str;
     int x=0;
     while(*ptr!='\0')
      {
             if(*ptr==n)
               {
                   printf("the character %c is present in the string",n);
                   x++;
               }
     }
  if(x==0)
    {
         printf("the character %c is not present in the string",n);
    }
}
int main()
{
   char c[50],n;
   printf("enter the charcaters which you want to search for");
   scanf("%c",&n);
   present(c,n);
   return 0;
}
